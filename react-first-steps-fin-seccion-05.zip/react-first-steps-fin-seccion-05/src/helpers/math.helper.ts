export const add = (a: number, b: number) => {
  // a++;

  return a + b;
};

export const subtract = (a: number, b: number) => {
  return a - b;
};

export const multiply = (a: number, b: number) => {
  return a * b;
};

// ! NO LO TOQUEN, NO HAGAN PRUEBAS
export const divide = (a: number, b: number) => {
  return a / b;
};
