export const HeroPage = () => {
  return <div>HeroPage</div>;
};
