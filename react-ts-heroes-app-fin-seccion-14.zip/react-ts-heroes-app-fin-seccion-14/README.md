# Heroes APP

## Levantar desarrollo

1. Clonar el repositorio
2. Editar el archivo `.env` con las variables de entorno basado en el archivo `.env.template`
3. Ejecutar `npm install`
4. Ejecutar `npm run dev`
